from flask import render_template,request,session,g,flash,Flask,redirect,url_for
from Controller import Configure
import pyrebase
import datetime
import smtplib
import requests
import random
import string
