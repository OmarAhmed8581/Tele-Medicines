
firebaseConfig = {
    "apiKey": "AIzaSyAAZSDa4A3ytc-QbeIYCV86QPzlexS2HOg",
    "authDomain": "telemedicines-123c0.firebaseapp.com",
    "databaseURL": "https://telemedicines-123c0.firebaseio.com",
    "projectId": "telemedicines-123c0",
    "storageBucket": "telemedicines-123c0.appspot.com",
    "messagingSenderId": "490806536805",
    "appId": "1:490806536805:web:73a3b462b3e52df8c5748c",
    "measurementId": "G-QPEMY0KWSQ"
  };